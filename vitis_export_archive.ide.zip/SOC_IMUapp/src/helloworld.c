#include "xparameters.h"
#include "xiic.h"
#include "xil_printf.h"
#include "sleep.h"

#define IIC_DEVICE_ID  XPAR_AXI_IIC_0_DEVICE_ID
#define IIC_SLAVE_ADDR 0x68

float accel_scale = 16384.0;  // LSB/g for �2g
float gyro_scale = 131.0;     // LSB/(�/s) for �250�/s




XIic IicInstance;

int i2c_write(u8 addr, u8 *data, int length);
int i2c_read(u8 addr, u8 *buffer, int length);

int i2c_write_reg(u8 reg) {
    return i2c_write(IIC_SLAVE_ADDR, &reg, 1);
}

int i2c_read_reg(u8 reg, u8 *buffer, int length) {
    if (i2c_write(IIC_SLAVE_ADDR, &reg, 1) != XST_SUCCESS) return XST_FAILURE;
    return i2c_read(IIC_SLAVE_ADDR, buffer, length);
}

int i2c_write(u8 addr, u8 *data, int length) {
    XIic_SetAddress(&IicInstance, XII_ADDR_TO_SEND_TYPE, addr);
    int sent = XIic_Send(IicInstance.BaseAddress, addr, data, length, XIIC_STOP);
    return (sent == length) ? XST_SUCCESS : XST_FAILURE;
}

int i2c_read(u8 addr, u8 *buffer, int length) {
    XIic_SetAddress(&IicInstance, XII_ADDR_TO_SEND_TYPE, addr);
    int received = XIic_Recv(IicInstance.BaseAddress, addr, buffer, length, XIIC_STOP);
    return (received == length) ? XST_SUCCESS : XST_FAILURE;
}

short combine(u8 high, u8 low) {
    return (short)((high << 8) | low);
}

int main() {
    int Status;
    u8 Data[14];

    Status = XIic_Initialize(&IicInstance, IIC_DEVICE_ID);
    if (Status != XST_SUCCESS) return XST_FAILURE;

    XIic_Start(&IicInstance);

    // Wake up MPU6050 (exit sleep mode)
    u8 config1[2] = {0x6B, 0x00}; // Wake up
    u8 config2[2] = {0x1B, 0x00}; // Gyro �250�/s
    u8 config3[2] = {0x1C, 0x00}; // Accel �2g

    i2c_write(IIC_SLAVE_ADDR, config1, 2);
    i2c_write(IIC_SLAVE_ADDR, config2, 2);
    i2c_write(IIC_SLAVE_ADDR, config3, 2);


    while (1) {
        Status = i2c_read_reg(0x3B, Data, 14);
        if (Status != XST_SUCCESS) {
            xil_printf("Read failed\n");
        } else {
            short ax = combine(Data[0], Data[1]);
            short ay = combine(Data[2], Data[3]);
            short az = combine(Data[4], Data[5]);
            short temp = combine(Data[6], Data[7]);
            short gx = combine(Data[8], Data[9]);
            short gy = combine(Data[10], Data[11]);
            short gz = combine(Data[12], Data[13]);

            float ax_f = ax / accel_scale;
            float ay_f = ay / accel_scale;
            float az_f = az / accel_scale;
            float gx_f = gx / gyro_scale + 4.6;
            float gy_f = gy / gyro_scale - 0.2;
            float gz_f = gz / gyro_scale - 1.0;
            float temp_c = (temp / 340.0) + 36.53;

            xil_printf("ACC: %d.%02d %d.%02d %d.%02d g | TEMP: %d.%02d C | GYRO: %d.%02d %d.%02d %d.%02d dps\n\r",
                (int)(ax_f), abs((int)(ax_f * 100) % 100),
                (int)(ay_f), abs((int)(ay_f * 100) % 100),
                (int)(az_f), abs((int)(az_f * 100) % 100),
                (int)(temp_c), abs((int)(temp_c * 100) % 100),
                (int)(gx_f), abs((int)(gx_f * 100) % 100),
                (int)(gy_f), abs((int)(gy_f * 100) % 100),
                (int)(gz_f), abs((int)(gz_f * 100) % 100));
        }

        usleep(1000000);
    }

    XIic_Stop(&IicInstance);
    return 0;
}
